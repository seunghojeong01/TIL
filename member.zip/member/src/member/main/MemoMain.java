package member.main;

import java.util.List;
import java.util.Scanner;


import member.dao.MemoDAO;
import member.jdbc.DBConn;

import member.vo.MemoVO;

public class MemoMain {
	private Scanner sc;// 멤버 필드로 선언
	MemoVO vo=new MemoVO();
	private MemoDAO dao;
	
	
	
	public MemoMain() {
		sc=new Scanner(System.in);//멤버 필드 초기화
		dao =new MemoDAO();
	}
	public static void main(String[] args) {
		MemoMain main=new MemoMain();
		while(true) {
		main.menu();	
	}
	}

		
	
	public void menu() {
		System.out.println("-----------------------------------");
		System.out.println("   MEMO MANAGEMENT SYSTEM   ");
		System.out.println("-----------------------------------");
		System.out.println("   1.전체목록");
		System.out.println("   2.내가 작성한 목록");
		System.out.println("   3.메모 작성하기");		
		System.out.println("   4.로그아웃");
		System.out.print("   >>선택:");
		int a=sc.nextInt();
		switch(a) {
		case 1: list(); break;
		case 2: mylist();
				int b=sc.nextInt();
				switch(b) {
				case 1:modify(); break;
				case 2:remove(); break;
				case 3:menu();  break;
				default:
					System.out.println("돌아갑니다.");
					break;
				}
						break;
		case 3: join(); break;
		case 4:
			MemberMain membermain =new MemberMain();
			membermain.menufirst();
		default:
			System.out.println("1~3를 입력하세요");
			menu();
		}
	}
	public void join() {
		System.out.println("-----------------------------------");
		System.out.println("          MEMO INPUT   ");
		System.out.println("-----------------------------------");
		System.out.print("메모 입력 :");
		vo.setMemo(sc.next());
		vo.setMid(MemberMain.id);
		
		boolean result;
		result = dao.insert(vo);
		if(result==true) {
			System.out.println("작성 완료");
			menu();
		}else {
			System.out.println("작성 실패");
			join();
		}	
		
	}
	public void list() { 
		System.out.println("-----------------------------------");
		System.out.println("          MEMO LIST   ");
		System.out.println("-----------------------------------");
		List<MemoVO> mvolist=dao.select();
		
		if(mvolist.size()>0) {
			/*
			 * for(int i=0;i<mvolist.size();i++) {
			 * System.out.println(" "+mvolist.get(i).getMid()+"\t"+mvolist.get(i).getMname()
			 * + "\t"+mvolist.get(i).getMage()+"\t"+mvolist.get(i).getMphone()+
			 * "\t"+mvolist.get(i).getMdate()); }
			 */
			//--------forEach문 이용------------------
			System.out.println(" 번호\t메모\t\t아이디\t\t작성일자");
			for (MemoVO mvo : mvolist) {
				System.out.println(" "+mvo.getMno()+"\t"+mvo.getMemo()+
						"\t\t"+mvo.getMid()+"\t\t"+mvo.getRegDate());
				
			}  menu();
			}else {
				System.out.println("   작성된 내용이 없습니다.");
				menu();
			}
		
		
	}
	public void list2() { 
		System.out.println("-----------------------------------");
		System.out.println("          MEMO LIST   ");
		System.out.println("-----------------------------------");
		List<MemoVO> mvolist=dao.select();
		
		if(mvolist.size()>0) {
			/*
			 * for(int i=0;i<mvolist.size();i++) {
			 * System.out.println(" "+mvolist.get(i).getMid()+"\t"+mvolist.get(i).getMname()
			 * + "\t"+mvolist.get(i).getMage()+"\t"+mvolist.get(i).getMphone()+
			 * "\t"+mvolist.get(i).getMdate()); }
			 */
			//--------forEach문 이용------------------
			System.out.println(" 번호\t메모\t\t아이디\t\t작성일자");
			for (MemoVO mvo : mvolist) {
				System.out.println(" "+mvo.getMno()+"\t"+mvo.getMemo()+
						"\t\t"+mvo.getMid()+"\t\t"+mvo.getRegDate());
				
			}  
			}else {
				System.out.println("   작성된 내용이 없습니다.");
			
			}
		
		
	}
	public void mylist() {
		System.out.println("-----------------------------------");
		System.out.println("       MY MEMO LIST   ");
		System.out.println("-----------------------------------");
		List<MemoVO> mvolist=dao.select(MemberMain.id);
		if(mvolist.size()>0) {
			System.out.println(" 번호\t메모\t\t아이디\t\t작성일자");
			for (MemoVO mvo : mvolist) {
				System.out.println(" "+mvo.getMno()+"\t"+mvo.getMemo()+
						"\t\t"+mvo.getMid()+"\t\t"+mvo.getRegDate());
				
			}//for end
			System.out.println("-----------------------------------");
			System.out.println("   1.수정하기   2.삭제하기   3.메뉴로 돌아간다.");
			}else {
				System.out.println("   작성된 내용이 없습니다.");
				menu();
			}
		
		}
	
	public void modify() {
		System.out.println("-----------------------------------");
		System.out.println("          MEMO UPDATE   ");
		System.out.println("-----------------------------------");
				
		System.out.print("   수정하고 싶은 게시물 번호: ");
		vo.setMno(sc.nextInt());
		System.out.print("   수정할 내용 : ");
		vo.setMemo(sc.next());
		dao.update(vo);
		
		if(vo != null) {
			System.out.println("------------------------------");
			System.out.println("     수정되었습니다.");
			System.out.println("==============================");
			System.out.println(" "+vo.getMno()+"\t"+vo.getMemo());
		}
		menu();
	}
	
	
	public void remove() {
		System.out.println("삭제하고 싶은 게시판 번호를 입력하세요");
		vo.setMno(sc.nextInt());
		dao.delete(vo.getMno());
		System.out.println("------------------------------");
		System.out.println("     삭제되었습니다.");
		System.out.println("==============================");
		menu();
	}
	
	public void remove2() {
		System.out.println("삭제하고 싶은 게시판 번호를 입력하세요");
		vo.setMno(sc.nextInt());
		dao.delete(vo.getMno());
		System.out.println("------------------------------");
		System.out.println("     삭제되었습니다.");
		System.out.println("==============================");
		
	}
	

}
