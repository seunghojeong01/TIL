package member.main;

import java.util.List;
import java.util.Scanner;

import member.dao.MemberDAO;
import member.jdbc.DBConn;
import member.vo.MemberVo;

public class MemberMain {
	private Scanner sc;// 멤버 필드로 선언
	MemberVo vo=new MemberVo();
	private MemberDAO dao;
	public static String id;
	MemoMain mm =new MemoMain();
	
	public MemberMain() {
		sc=new Scanner(System.in);//멤버 필드 초기화
		dao =new MemberDAO();
	}
	public static void main(String[] args) {
		MemberMain main=new MemberMain();
		while(true) {
		main.menufirst();	
	}

	}
	public void menufirst() {
		System.out.println("-----------------------------------");
		System.out.println("   MEMO MANAGEMENT SYSTEM   ");
		System.out.println("-----------------------------------");
		System.out.println("   1.로그인");
		System.out.println("   2.회원가입");
		System.out.println("   3.종료");
		System.out.print("   >>선택:");
		int a=sc.nextInt();
		switch(a) {
		case 1: login(); break;
		case 2: join(); break;
		case 3:
			System.out.println("-----------------------------------");
			System.out.println("      프로그램을 종료합니다.     ");
			sc.close();
			DBConn.close();
			System.exit(0);
		default:
			System.out.println("1~3를 입력하세요");
			menuadmin();
		}
	}
	public void login() {
		System.out.println("-----------------------------------");
		System.out.println("             LOGIN                 ");
		System.out.println("-----------------------------------");
		System.out.print("   아이디 입력:");
		id=sc.next();
		System.out.print("   핸드폰 번호 입력:");
		String phone=sc.next();
		
		if(id.equals("admin") && phone.equals("1111")) {
		System.out.println(" 관리자 로그인");
		menuadmin();
		}else {
			
			if(dao.login(id,phone) == true) {
				System.out.println("   로그인 성공");
				mm.menu();
			}else {
				System.out.println("   로그인 실패");
				login();
		}
		}
		
	}
	public void menuadmin() {
		System.out.println("-----------------------------------");
		System.out.println("   MEMBER MANAGEMENT SYSTEM   ");
		System.out.println("-----------------------------------");
		System.out.println("   1.회원목록");
		System.out.println("   2.회원조회");
		System.out.println("   3.전체메모리스트");
		System.out.println("   4.종료");
		System.out.print("   >>선택:");
		int a=sc.nextInt();
		
		switch(a) {
		case 1: list(); break;
		case 2: info();
				int b=sc.nextInt();
				switch(b) {
				case 1: modify(); break;
				case 2: remove(); break;
				case 3: break;
				}
				break;
		case 3:MemoMain memo=new MemoMain();
				memo.list2();
				System.out.println("-----------------------------------");
				System.out.println("   1.수정하기   2.삭제하기   3.메뉴로 돌아간다.");
				int c=sc.nextInt();
				switch(c) {
				case 1:memo.modify(); break;
				case 2:memo.remove2(); break;
				case 3:menuadmin();  break;
				default:
					System.out.println("돌아갑니다.");
					break;
				}break;
		case 4:
			System.out.println("프로그램을 종료합니다.");
			sc.close();
			DBConn.close();
			System.exit(0);
			break;
		default:
			System.out.println("1~3를 입력하세요");
			menuadmin();
		}
	}
	public void join() {
		System.out.println("-----------------------------------");
		System.out.println("          MEMBER JOIN   ");
		System.out.println("-----------------------------------");
		System.out.print("아이디 입력 :");
		vo.setMid(sc.next());
		System.out.print("회원이름 :");
		vo.setMname(sc.next());
		System.out.print("나이 :");
		vo.setMage(sc.nextInt());
		System.out.print("전화번호 :");
		vo.setMphone(sc.next());		
		
		boolean result;
		result = dao.insert(vo);
		if(result==true) {
			System.out.println("회원가입 완료");
		}else {
			System.out.println("회원가입 실패");
		}	
		
	}
	public void list() { 
		System.out.println("-----------------------------------");
		System.out.println("          MEMBER LIST   ");
		System.out.println("-----------------------------------");
		System.out.println(" 아이디\t이름\t나이\t전화번호\t\t가입일자");
		List<MemberVo> mvolist=dao.select();
		
		if(mvolist.size()>0) {
			/*
			 * for(int i=0;i<mvolist.size();i++) {
			 * System.out.println(" "+mvolist.get(i).getMid()+"\t"+mvolist.get(i).getMname()
			 * + "\t"+mvolist.get(i).getMage()+"\t"+mvolist.get(i).getMphone()+
			 * "\t"+mvolist.get(i).getMdate()); }
			 */
			//--------forEach문 이용------------------
			
			for (MemberVo mvo : mvolist) {
				System.out.println(" "+mvo.getMid()+"\t"+mvo.getMname()+
						"\t"+mvo.getMage()+"\t"+mvo.getMphone()+
						"\t"+mvo.getMdate());
			}
			}else {
				System.out.println("해당 아이디가 존재하지 않습니다.");
				menuadmin();
			}
		
		
	}
	public void info() {
		System.out.println("-----------------------------------");
		System.out.println("          MEMBER INFO   ");
		System.out.println("-----------------------------------");
		System.out.print("     조회 아이디 : ");
		String mid=sc.next(); //조회하고 싶은 아이디
		vo=dao.select(mid);//값을 vo로 넘겨줌
		if(vo != null) {
		System.out.println("     회원이름 : "+vo.getMname());
		System.out.println("     나이 : "+vo.getMage());
		System.out.println("     전화번호 : "+vo.getMphone());
		System.out.println("     가입일자 : "+vo.getMdate());
		System.out.println("     --------------------------------");
		System.out.println("     1. 회원 수정    2. 회원 삭제   3.메인 메뉴");
		System.out.print("     >>선택:");
		}else {
			System.out.println("해당 아이디가 존재하지 않습니다.");
			menuadmin();
		}
		
	}
	
	public void modify() {
		System.out.println("-----------------------------------");
		System.out.println("          MEMBER UPDATE   ");
		System.out.println("-----------------------------------");
				
		System.out.print("     업데이트(나이) : ");
		vo.setMage(sc.nextInt());
		System.out.print("     업데이트(핸드폰 번호) : ");
		vo.setMphone(sc.next());
		dao.update(vo);
		
		if(vo != null) {
			System.out.println("------------------------------");
			System.out.println("     수정되었습니다.");
			System.out.println("==============================");
			System.out.println("     회원이름 : "+vo.getMname());
			System.out.println("     나이 : "+vo.getMage());
			System.out.println("     전화번호 : "+vo.getMphone());
			System.out.println("     가입일자 : "+vo.getMdate());
		}
	}
	
	
	public void remove() {
		dao.delete(vo.getMid());
		System.out.println("------------------------------");
		System.out.println("     삭제되었습니다.");
		System.out.println("==============================");
	}
	
	

}
