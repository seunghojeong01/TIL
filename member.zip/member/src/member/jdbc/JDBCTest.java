package member.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import member.vo.MemberVo;

public class JDBCTest {
	String driver="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String username="dev";
	String password="0000";
	
	String query="";
	Statement stmt=null;
	Connection con=null;
	PreparedStatement pstmt;
	
	public static void main(String[] args) throws SQLException {
		// JDBC ; Java DataBase Connectivity
		// 자바 어플리케이션과 데이터베이스를 연결하는 라이브러리
		// 자바 프로그램에서 DB에 접근하기 위해 사용

		// 1.DBMS;DataBase Management System 설치
		// 2.DBMS에 맞는 JDBC 드라이버 설치
		// 3.JDBC API를 이용하여 자바 프로그램 개발
		//   1단계-sql 관련 패키지 import
		//   2단계-JDBC 드라이버 로드
		//   3단계-Connection 객체 생성
		//   4단계-Statement/PreparedStatement 객체 생성
		//   5단계-쿼리 실행
		//   6단계-필요 시 ResultSet 객체 생성 사용
		//   7단계-모든 객체를 닫고 DB 연결 종료	
		JDBCTest t=new JDBCTest();
		t.insert();
		}
	public void insert() throws SQLException {
		MemberVo mvo=new MemberVo();
		mvo.setMid("bbb");
		mvo.setMname("KIM");
		mvo.setMage(23);
		mvo.setMphone("010-2020-2030");
		
		try {
			Class.forName(driver);
			System.out.println("driver ok");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  //드라이버 로딩	
	
		con=DriverManager.getConnection(url,username,password);
//		con.setAutoCommit(false);   //원래  자동으로 true
//		con.commit();
		stmt=con.createStatement();	
		
		query="INSERT INTO t_member VALUES (?,?,?,?,SYSDATE)";	
		pstmt=con.prepareStatement(query);
		pstmt.setString(1, mvo.getMid());
		pstmt.setString(2, mvo.getMname());
		pstmt.setInt(3, mvo.getMage());
		pstmt.setString(4, mvo.getMphone());
		
		
		pstmt.executeUpdate();//회원 추가 쿼리 실행
		
		
		pstmt.close();
		con.close();
	}
	
	public void update() throws SQLException  {
		try {
			Class.forName(driver);
			System.out.println("driver ok");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  //드라이버 로딩
		
		
	
		con=DriverManager.getConnection(url,username,password);
//		con.setAutoCommit(false);   //원래  자동으로 true
//		con.commit();
		stmt=con.createStatement();
	
		query=" UPDATE t_member SET mname='LEE' WHERE mid='df'"; 
		
		stmt.executeUpdate(query);
		
		stmt.close();
		con.close();
	}
	
	public void delete() throws SQLException {
		try {
			Class.forName(driver);
			System.out.println("driver ok");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}  //드라이버 로딩	
	
		con=DriverManager.getConnection(url,username,password);
//		con.setAutoCommit(false);   //원래  자동으로 true
//		con.commit();
		stmt=con.createStatement();
	
		query="DELETE FROM t_member WHERE mid='mbab'";
		stmt.executeUpdate(query);//회원 추가 쿼리 실행
		
		stmt.close();
		con.close();
	}
}
