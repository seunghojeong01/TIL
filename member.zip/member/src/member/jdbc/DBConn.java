package member.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConn {
	private static Connection con;
	private DBConn() {}//1.외부에서 접근할 수 없는 기본생성자 작성
	public static  Connection getConnection(){//2.Connection 객체를 반환하는 공유 메서드 getConnection()작성
		String driver="oracle.jdbc.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String username="dev";
		String password="0000";

		
		if (con==null) {
			try {
				Class.forName(driver);
				con=DriverManager.getConnection(url,username,password);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return con;
	}
	public static void close(Statement stmt){//3.Statement를 매개변수로 받아서 닫는 close()
		try {
		if(stmt != null) stmt.close();
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public static void close(PreparedStatement pstmt){//4.preparedStatement 객체를 매개변수로 받아서 닫는 메서드 close() 작성
		try {
			if(pstmt != null) pstmt.close();
			
			}catch(SQLException e) {
				e.printStackTrace();
			}
		
	}
	
	public static void close() {
		try {
			if(con != null) con.close();
			
			}catch(SQLException e) {
				e.printStackTrace();
			}
	}
	public static void close(PreparedStatement pstmt,ResultSet rs) {
	try {
		if(rs != null) rs.close();
		if(pstmt != null) pstmt.close();
		
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
