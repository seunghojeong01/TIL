package member.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import member.jdbc.DBConn;
import member.vo.MemoVO;
public class MemoDAO {
	private String query; //쿼리문 저장 필드
	private PreparedStatement pstmt;
	private ResultSet rs;
	//회원 리스트-매개변수:x 접근제한:x 반환타입:MemberVo를 저장한 List
	//			기능:t_member 테이블의 전체 데이터를 조회하여 List에 저장한 후 반환
	public List<MemoVO> select() {
		List<MemoVO> mvolist=new ArrayList<>();
		MemoVO vo =null;
		
		try {
			query="SELECT * FROM t_memo ";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			
			rs=pstmt.executeQuery();			
			while(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				vo=new MemoVO();
				vo.setMno(rs.getInt("mno"));
				vo.setMemo(rs.getString("memo"));
				vo.setMid(rs.getString("mid"));
				vo.setRegDate(rs.getDate("reg_date"));
				//List객체에 추가
				mvolist.add(vo);
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return mvolist;
	}
	public List<MemoVO> select(String mid) {
		MemoVO vo=null;
		List<MemoVO> mvolist=new ArrayList<>();
		try {
			query="SELECT * FROM t_memo WHERE mid=? ORDER BY mno DESC";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setString(1,mid);
			rs=pstmt.executeQuery();			
			while(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				vo=new MemoVO();
				vo.setMno(rs.getInt("mno"));
				vo.setMemo(rs.getString("memo"));
				vo.setMid(rs.getString("mid"));
				vo.setRegDate(rs.getDate("reg_date"));
				mvolist.add(vo);
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return mvolist;
	}
	
	//회원 조회-매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장항여 반환하는 메서드
	public MemoVO select(int mno) {
		MemoVO vo=null;
		try {
			query="SELECT * FROM t_memo WHERE mno=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setInt(1, mno);
			rs=pstmt.executeQuery();			
			if(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				vo=new MemoVO();
				vo.setMno(rs.getInt("mno"));
				vo.setMemo(rs.getString("memo"));
				vo.setMid(rs.getString("mid"));
				vo.setRegDate(rs.getDate("reg_date"));
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return vo;
	}
	

	
	public boolean insert(MemoVO mvo) {
	      
	      try {
	         //insert 쿼리문
	         query = "INSERT INTO t_memo VALUES(MEMO_SEQ.NEXTVAL,?,?,SYSDATE)";
	         
	         pstmt = DBConn.getConnection().prepareStatement(query);
	        
	         pstmt.setString(1, mvo.getMemo());
	         pstmt.setString(2, mvo.getMid());
	         
	         
	         int result = pstmt.executeUpdate();
	         if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }

	      //매개변수로 넘겨받은 데이터를 t_member 테이블에 저장
	      //insert 쿼리문
	      return false;//정상적으로 회원가입 성공 시 true 반환
	               // 그렇지 않으면 false 반환
	   }//insert END

	
	public boolean update(MemoVO vo) {
		try {
			query="UPDATE t_memo SET memo=? WHERE mno=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setString(1, vo.getMemo());
			pstmt.setInt(2, vo.getMno());
			
			 int result = pstmt.executeUpdate();
	         if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }
		return true;
	}
	
	public boolean delete(int mno) {
		
		try {
			query="DELETE FROM t_memo WHERE mno=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setInt(1, mno);
			int result = pstmt.executeUpdate();
	        if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
		}catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }
		
		
		return true;
	}
}