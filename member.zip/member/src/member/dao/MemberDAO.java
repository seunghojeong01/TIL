package member.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import member.jdbc.DBConn;
import member.vo.MemberVo;
public class MemberDAO {
	private String query; //쿼리문 저장 필드
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	//회원 리스트-매개변수:x 접근제한:x 반환타입:MemberVo를 저장한 List
	//			기능:t_member 테이블의 전체 데이터를 조회하여 List에 저장한 후 반환
	public List<MemberVo> select() {
		List<MemberVo> mvolist=new ArrayList<>();
		MemberVo mvo =null;
		
		try {
			query="SELECT * FROM t_member ";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			
			rs=pstmt.executeQuery();			
			while(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				mvo=new MemberVo();
				mvo.setMid(rs.getString("mid"));
				mvo.setMname(rs.getString("mname"));
				mvo.setMage(rs.getInt("age"));
				mvo.setMphone(rs.getString("phone"));
				mvo.setMdate(rs.getDate("reg_date"));
				//List객체에 추가
				mvolist.add(mvo);
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return mvolist;
	}
	public MemberVo select(String mid) {
		MemberVo vo=null;
		
		try {
			query="SELECT * FROM t_memo WHERE mid=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setString(1, mid);
			rs=pstmt.executeQuery();			
			if(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				vo=new MemberVo();
				vo.setMid(rs.getString("mid"));
				vo.setMname(rs.getString("mname"));
				vo.setMage(rs.getInt("age"));
				vo.setMphone(rs.getString("phone"));
				vo.setMdate(rs.getDate("reg_date"));
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return vo;
	}
	
	//회원 조회-매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장항여 반환하는 메서드

	
	public boolean login(String mid,String phone) {
	
		try {
			query="SELECT COUNT(*) FROM t_member WHERE mid=? AND phone=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setString(1, mid);
			pstmt.setString(2, phone);
			rs=pstmt.executeQuery();			
			if(rs.next()==true) {//조회된 레코드가 있다면 MemberVo 객체 생성하여 해당 레코드 값 저장
				if(rs.getInt(1)==1) {
					return true;
				}else {
					return false;
				}
				
			}
			} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBConn.close(pstmt,rs);
		}
		return true;
	}
	
	public boolean insert(MemberVo mvo) {
	      
	      try {
	         //insert 쿼리문
	         query = "INSERT INTO t_member VALUES(?,?,?,?,SYSDATE)";
	         
	         pstmt = DBConn.getConnection().prepareStatement(query);
	         pstmt.setString(1, mvo.getMid());
	         pstmt.setString(2, mvo.getMname());
	         pstmt.setInt(3, mvo.getMage());
	         pstmt.setString(4, mvo.getMphone());
	         
	         int result = pstmt.executeUpdate();
	         if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }

	      //매개변수로 넘겨받은 데이터를 t_member 테이블에 저장
	      //insert 쿼리문
	      return false;//정상적으로 회원가입 성공 시 true 반환
	               // 그렇지 않으면 false 반환
	   }//insert END

	
	public boolean update(MemberVo mvo) {
		try {
			query="UPDATE t_member SET age=?,phone=? WHERE mid=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setInt(1, mvo.getMage());
			pstmt.setString(2, mvo.getMphone());
			pstmt.setString(3, mvo.getMid());
			
			 int result = pstmt.executeUpdate();
	         if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }
		return true;
	}
	
	public boolean delete(String mid) {
		
		try {
			query="DELETE FROM t_member WHERE mid=?";	
			pstmt=DBConn.getConnection().prepareStatement(query);
			pstmt.setString(1, mid);
			int result = pstmt.executeUpdate();
	        if(result !=0) {
	            return true;
	         } else {
	            return false;
	         }
		}catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         DBConn.close(pstmt);
	      }
		
		
		return true;
	}
}
